<p align="center">
  <a href="https://cloud.ibm.com"><img src="https://cloud.ibm.com/media/docs/developer-appservice/resources/ibm-cloud.svg" height="100" alt="IBM Cloud"></a>
</p>

# Node.js application

Test application for the IEA: Electric Vehicle Data

# Installation

npm install
